﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Senparc.Weixin.MP.Test.CommonAPIs;

namespace Senparc.Weixin.MP.Test.Containers
{
    [TestClass]
    public class AccessTokenContainerLockTest : CommonApiTest
    {
        [TestMethod]
        public void LockTest()
        {

        }
    }
}
