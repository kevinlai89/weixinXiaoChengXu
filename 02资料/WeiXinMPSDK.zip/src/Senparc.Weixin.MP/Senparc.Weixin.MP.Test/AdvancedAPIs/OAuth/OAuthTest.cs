﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Senparc.Weixin.MP.Test.CommonAPIs;

namespace Senparc.Weixin.MP.Test.AdvancedAPIs.OAuth
{
    public class OAuthTest : CommonApiTest
    {
        [TestMethod]
        public void GetAuthorizeUrlTest()
        {
            //由于需要结合外网，请看Sample中的测试
        }
    }
}
